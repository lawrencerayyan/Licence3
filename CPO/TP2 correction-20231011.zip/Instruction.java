package asmA;

public abstract class Instruction {
	abstract boolean execute (Machine m);
}
