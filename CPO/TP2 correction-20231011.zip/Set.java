package asmA;

public class Set extends Instruction {

	private int index;
	private int value;

	Set(int n, int v) {
		index = n;
		value = v;
	}

	@Override
	public String toString() {
		return "Set (" + index + ", " + value + ")";
	}

	@Override
	boolean execute(Machine m) {
		System.out.println(this);
		if (m.setMemory(index, value)){
			return m.nextInstruction();
		}
		else
			return false;
	}

}
	