package FinalPacman;

public interface GameState {
void handleState(FinalPacman.Board board);
} 
