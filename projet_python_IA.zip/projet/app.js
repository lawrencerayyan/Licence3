const express = require('express');
const fs = require('fs').promises;
const { exec } = require('child_process');

const app = express();
const port = 8080; 
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.get('/form', async (req, res) => {
    try {
        const formData = await fs.readFile('formulaire.html', 'utf-8');
        res.send(formData);
    } catch (error) {
        res.status(500).send('Une erreur est survenue lors de la lecture du fichier formulaire.html');
    }
});
const { spawn } = require('child_process');

app.post('/rep', (req, res) => {
    const {r,g,b,model } = req.body;
    const shapes = Object.keys(req.body)
        .filter(key => key.startsWith("shape"))
        .map(shape => req.body[shape]);
    const surfaces = Object.keys(req.body)
        .filter(key => key.startsWith("surface"))
        .map(surface => req.body[surface]);

    const pythonProcess = spawn('python', ['projet.ipynb', r, g, b, shapes.join(','), surfaces.join(','),]);

    let data = '';
    pythonProcess.stdout.on('data', (chunk) => {
        data += chunk.toString();
    });

    pythonProcess.on('close', (code) => {
        if (code !== 0) {
            console.error(`Failed with code ${code}`);
            res.status(500).send("Error processing the data");
        } else {
            res.send(`Prediction: ${data}`);
        }
    });
});



app.listen(8080, () => console.log(`Serveur Express en écoute sur le port ${port}`));
